
# Airsoft · Sitio web 

Sitio navegable de la agencia de viajes Airsoft, construido a partir de los mockups del Manual de Marca v1.0. Usa datos simulados

## Cómo abrirlo

1. Descomprime el `.zip` y abre la carpeta `airsoft` en Visual Studio Code (Archivo > Abrir carpeta).
2. Instala la extensión live server 
3. Clic derecho sobre `index.html` > **Open with Live Server**. Se abre en Chrome en `http://127.0.0.1:5500`.

También funciona con doble clic sobre `index.html`, sin Live Server.

## Cuenta de prueba

- Correo: `demo@airsoft.co`
- Contraseña: `Viaja2026`
- Tarjeta de prueba: `4111 1111 1111 1111`, vencimiento `08/29`, CVV `123`

## Pruebas para el sprint review (HU-16 y HU-19)

La tasa del día es simulada. En los paquetes internacionales hay una línea "Prueba de la demo" con botones para mostrar los casos especiales sin tocar la dirección:

- En el pago: "Simular que el dólar subió" muestra el aviso amarillo de la HU-16.
- En el detalle y en el pago: "Simular que la TRM no responde" muestra la conversión no disponible y bloquea la reserva (HU-19).
- "Volver a la tasa normal" deja todo como antes.

## Estructura

```
airsoft/
├── index.html        Estructura base: encabezado, pie de página y avisos
├── assets/logo.png   Isotipo tomado del manual de marca
├── css/styles.css    Colores, tipografía y diseño responsive
└── js/
    ├── utils.js      Formato de fechas y precios, almacenamiento local
    ├── data.js       Destinos, hoteles, paquetes e itinerarios simulados
    ├── state.js      Estado de la app, cuenta de prueba y cálculo de precios
    ├── ui.js         Avisos, encabezado y buscador
    ├── views.js      Una función por pantalla (vHome, vResults, vDetail...)
    ├── pages.js      Páginas institucionales: vacantes, postulación, blog, ayuda y términos (HU-09 a HU-12)
    └── app.js        Enrutador por hash (#/...) y manejo de eventos
```

Los scripts se cargan en ese orden en `index.html`, porque cada archivo usa lo que definen los anteriores.

## Pantallas por historia de usuario

| HU | Pantalla | Ruta | Función en `views.js` |
|----|----------|------|-----------------------|
| 1 | Inicio y buscador | `#/` | `vHome` |
| 2 | Registro | `#/registro` | `vAuth("registro")` |
| 3 | Inicio de sesión y recuperación de contraseña | `#/login`, `#/recuperar` | `vAuth("login")`, `vRecover` |
| 4 | Búsqueda de paquetes | `#/resultados` | `vResults` |
| 5 | Selección de hotel | `#/hoteles?pkg=c1` | `vHotels` |
| 6 | Detalle del paquete | `#/paquete/c1` | `vDetail` |
| 7 | Pago | `#/pago` | `vPay` |
| 8 | Confirmación de la reserva | `#/confirmacion/...` | `vConfirm` |
| 8.1 | Mis reservas | `#/mis-reservas` | `vMine` |
| 9 | Trabaja con nosotros | `#/trabaja` | `vCarreras` (en `pages.js`) |
| 9.1 | Postulación a una vacante | `#/trabaja/aplicar/frontend` | `vAplicar` (en `pages.js`) |
| 9.2 | Envío de hoja de vida general | `#/trabaja/aplicar/general` | `vAplicar` (en `pages.js`) |
| 10 | Artículo del blog | `#/blog`, `#/blog/razones-cartagena` | `vBlog`, `vArticulo` (en `pages.js`) |
| 11 | Centro de ayuda | `#/ayuda` | `vAyuda` (en `pages.js`) |
| 12 | Términos y condiciones | `#/terminos` | `vTerminos` (en `pages.js`) |
| 13 | Buscador nacional / internacional y países disponibles | `#/` | `searchForm` (en `ui.js`), `vHome` |
| 14 | País y precio en dólares con su equivalente en pesos | `#/resultados` | `renderResultList`, `precioHTML` (en `state.js`) |
| 15 | Equivalente en pesos con la tasa del día | `#/paquete/n1` | `vDetail`, `tasaPanel` |
| 16 | Precio en pesos fijo al confirmar la reserva | `#/pago` | `vPay` |
| 17 | Requisitos de viaje del destino | `#/paquete/n1` | `requisitosHTML` |
| 18 | Agencias por país y fechas | `#/agencias` | `vAgencias` |
| 19 | Tasa de cambio de una fuente oficial | todas las pantallas con precios internacionales | `trmDelDia` (en `state.js`) |

## Para conectar el backend

Los datos viven en `js/data.js` (catálogo) y en `localStorage` (usuarios y reservas, ver `store` en `js/utils.js`). Para pasar a una API, se reemplazan esas lecturas y escrituras por llamadas `fetch` sin tocar las vistas.

## Subirlo a GitHub

1. Crea un repositorio vacío en GitHub (sin README ni .gitignore).
2. En VS Code abre la terminal (Terminal > Nueva terminal) dentro de la carpeta `airsoft` y ejecuta:

```bash
git init
git add .
git commit -m "Demo navegable de Airsoft para el sprint review"
git branch -M main
git remote add origin https://github.com/USUARIO/NOMBRE-DEL-REPO.git
git push -u origin main
```

Cambia `USUARIO` y `NOMBRE-DEL-REPO` por los de tu repositorio.


## Cómo colaborar

Nadie sube cambios directo a `main`. Cada cambio va en su propia rama y entra al proyecto por pull request, después de que alguien del equipo lo revise.

1. Actualiza tu copia: `git pull origin main`
2. Crea una rama con un nombre que diga qué vas a hacer: `git checkout -b nombre-del-cambio`
3. Haz tus cambios y guárdalos: `git add .` y luego `git commit -m "Qué cambiaste"`
4. Sube la rama: `git push origin nombre-del-cambio`
5. En GitHub abre el pull request con **Compare & pull request** y asigna a un compañero como revisor.
6. Cuando lo aprueben, se da clic en **Merge** y el cambio queda en `main`.